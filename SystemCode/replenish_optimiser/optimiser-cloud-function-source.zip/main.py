import functions_framework

@functions_framework.http
def smart_replenisher_http(request):
    """HTTP Cloud Function.
    Args:
        request (flask.Request): The request object.
        <https://flask.palletsprojects.com/en/1.1.x/api/#incoming-request-data>
    Returns:
        The response text, or any set of values that can be turned into a
        Response object using `make_response`
        <https://flask.palletsprojects.com/en/1.1.x/api/#flask.make_response>.
    Ref sample:
        https://github.com/GoogleCloudPlatform/python-docs-samples/blob/main/functions/helloworld/main.py
    """

    '''
    version 05 - 20th May 2023
    update: for google cloud function deployment
    Bianca ZYCao
    '''
    request_json = request.get_json(silent=True)
    request_args = request.args
    args_list = ['item_id','init_inventory', 'min_order_qty', 'lead_time', 'order_unit','demand']

    # validate request body
    if request_json:
        print("received request in json:", request_json)
        for arg in args_list:
            if arg not in request_json:
                raise ValueError(f"ERROR: JSON is invalid, or missing a {arg} property")
    else:
        raise ValueError("ERROR: request body not found.")
    
    from ortools.linear_solver import pywraplp
    # Create the MIP solver.
    solver = pywraplp.Solver.CreateSolver('SCIP')

    # Define the input data. 
    item_id = request_json['item_id']
    init_inventory_level = request_json['init_inventory']
    big_M = 2000
    demand = [request_json['demand']]
    num_of_demand_scenarios = len(demand)
    num_of_weeks = len(demand[0]) 
    lead_time = request_json['lead_time']
    min_order_qty = request_json['min_order_qty']
    order_unit = request_json['order_unit']
    # TODO: introduce more constraints type & define objective function Ordering_cost+holding_cost+penalty on stockout
    ordering_cost = 20
    holding_cost = 0.2
    unit_price = 1
    service_rate = 0.95
    order_placement_interval = 3
    # Define the decision variables.
    order_quantity = [solver.IntVar(0, 100, f'order_quantity_{i}') 
                        for i in range(num_of_weeks)]
    inventory_level = [[solver.IntVar(-500, 2000,  f'inventory_week{i}_scenario{j}') 
                        for i in range(num_of_weeks+1)] 
                        for j in range(num_of_demand_scenarios)]
    total_inventory_level_scenario = [solver.IntVar(-50000, solver.infinity(),  
                                                    f'exp_inventory_level_scenario{j}') 
                        for j in range(num_of_demand_scenarios)]
    stock_state  = [[solver.IntVar(0, 1, f'stock_state_week{i}_scenario{j}')
                        for i in range(num_of_weeks+1)] 
                        for j in range(num_of_demand_scenarios)]
    stock_state_sum = [solver.IntVar(0, num_of_weeks, f'stock_state_sum_scenario{j}') 
                        for j in range(num_of_demand_scenarios)]

    # Add constraint for each week's inventory level
    for j in range(num_of_demand_scenarios):
        solver.Add(inventory_level[j][0] == init_inventory_level)  # initial inventory level
        for i in range(num_of_weeks):
            if i % order_placement_interval != 0: 
                solver.Add(order_quantity[i] == 0)
            inventory_level[j][i+1] = inventory_level[j][i] - demand[j][i]
            if i >= lead_time - 1 :
                inventory_level[j][i+1] += order_quantity[i-(lead_time - 1)]*order_unit
            # add constraint to tell stock out or not
            solver.Add(inventory_level[j][i] <= stock_state[j][i] * big_M )
            solver.Add(inventory_level[j][i] >= 1/big_M - (1-stock_state[j][i]) * big_M )
        stock_state_sum[j] = sum(stock_state[j])
        total_inventory_level_scenario[j] = sum(inventory_level[j])
        
    # good case
    solver.Add(sum(stock_state_sum)>=service_rate*num_of_weeks*num_of_demand_scenarios)

    # Define the objective function to minimize inventory level.
    accum_inventory_level = sum(total_inventory_level_scenario)/num_of_demand_scenarios
    holding_value = unit_price * accum_inventory_level
    total_cost = ordering_cost * 3 + holding_value + holding_cost * holding_value
    solver.Minimize(accum_inventory_level)

    # Solve the optimization problem.
    status = solver.Solve()

    # Print the optimal order quantity and total cost.
    if status == pywraplp.Solver.OPTIMAL or status == pywraplp.Solver.FEASIBLE:
        print(f'[INFO] {item_id} Optimal or Feasible solution found.')
        print('Optimal order quantity: ', end='[' )
        for i in range(num_of_weeks):
            print(order_quantity[i].solution_value()*order_unit, end=', ' )
        service_rate = sum(stock_state_sum[j].solution_value() for j in range(num_of_demand_scenarios))/(num_of_weeks*num_of_demand_scenarios) 
        avg_inventory_level = sum(total_inventory_level_scenario[j].solution_value() for j in range(num_of_demand_scenarios))/(num_of_weeks*num_of_demand_scenarios)
        exp_inventory_level = []
        for i in range(num_of_weeks):
            exp_inventory_level.append(sum(inventory_level[j][i].solution_value() for j in range(num_of_demand_scenarios)))
        print(f'] service rate: {service_rate}; AVG inventory level: {avg_inventory_level}; ',
              f'Holding Value: {holding_value.solution_value()}; Total Cost: {total_cost.solution_value()}')
        print('\nAdvanced usage: Problem solved in %f milliseconds' % solver.wall_time(),'Problem solved in %d iterations' % solver.iterations())
        return {
            'item_id': item_id,
            'solution_found': True,
            'replenish_required_smart': order_quantity[0].solution_value()>0,
            'suggested_qty_smart': max(order_quantity[0].solution_value()*order_unit,min_order_qty) if order_quantity[0].solution_value()>0 else 0,
        }
    elif  status == pywraplp.Solver.INFEASIBLE:
        print(f'[INFO] {item_id} The problem is not feasible.')
        return { 
            'item_id': request_json['item_id'],
            'solution_found': False,
            'message': 'The problem is not feasible.'}
    elif  status == pywraplp.Solver.MODEL_INVALID:
        print(f'[INFO] {item_id} The model is not valid.')
        raise RuntimeError('The model is not valid.')
    else:
        print(f'[INFO] {item_id} something wrong!')
        raise RuntimeError('Something wrong!')