import pandas as pd
import  joblib
print("Pandas version:", pd.__version__)
print("Joblib version:", joblib.__version__)

import time
import numpy as np

from pycaret.datasets import get_data
from pycaret.time_series import *

y = pd.read_csv('sales_order.csv')
itemID = y.itemID.unique()[0]
y = y[y.itemID==itemID]
y.date = pd.to_datetime(y.date)
y = y.set_index('date')

# Sum the sales data for each day
y = y.groupby('date')['quantity'].agg('sum')

# Resample the data by week and sum the sales data for each week
y = y.resample('D').sum()

y.plot()
print(itemID)
print(type(itemID))
loaded_exp = TSForecastingExperiment()
m = loaded_exp.load_model(str(itemID))
# # Predictions should be same as before the model was saved and loaded
# loaded_exp.predict_model(m)

#generate input data for the model
data = y.copy()
data = data.reset_index()
data

#generate forecast
forecast = loaded_exp.predict_model(m, X=data, fh=12)
print(forecast)