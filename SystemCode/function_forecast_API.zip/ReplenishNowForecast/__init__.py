import pandas as pd
import joblib
import time
import numpy as np
from pycaret.datasets import get_data
from pycaret.time_series import *
import argparse
import logging
import json

import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        # Parse the JSON request body
        req_body = req.get_json()

        # Retrieve the input parameters from the request
        file_dict = req_body.get('file')
        itemID = req_body.get('itemID')
        fh = req_body.get('fh')

        if not file_dict:
            return func.HttpResponse("Please pass the 'file' parameters in the request.", status_code=400)
        
        if not itemID:
            return func.HttpResponse("Please pass the 'itemID' parameter in the request.", status_code=400)

        if not fh:
            return func.HttpResponse("Please pass the 'fh' parameter in the request.", status_code=400)


        # Load data from dictionary
        y = pd.DataFrame.from_dict(file_dict)

        # Filter data by itemID
        y = y[y.itemID == int(itemID)]

         # Convert date column to datetime
        y.date = pd.to_datetime(y.date)

        # Set date as index
        y = y.set_index('date')

        # Sum the sales data for each day
        y = y.groupby('date')['quantity'].agg('sum')

        # Resample the data by day and sum the sales data for each day
        y = y.resample('D').sum()

        loaded_exp = TSForecastingExperiment()
        m = loaded_exp.load_model(str(itemID))

        # Generate input data for the model
        data = y.copy()
        data = data.reset_index()

        # Generate forecast
        forecast = loaded_exp.predict_model(m, X=data, fh=int(fh))

        return func.HttpResponse(f"{forecast}")

    except ValueError:
        return func.HttpResponse("Invalid request data format. Please provide a valid JSON body.", status_code=400)